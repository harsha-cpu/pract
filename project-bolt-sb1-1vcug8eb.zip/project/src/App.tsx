import React, { useState } from 'react';
import { Equal, Delete, Plus, Minus, X, Divide } from 'lucide-react';

function App() {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [shouldResetDisplay, setShouldResetDisplay] = useState(false);

  const handleNumber = (num: string) => {
    if (display === '0' || shouldResetDisplay) {
      setDisplay(num);
      setShouldResetDisplay(false);
    } else {
      setDisplay(display + num);
    }
  };

  const handleOperator = (operator: string) => {
    setShouldResetDisplay(true);
    setEquation(display + ' ' + operator + ' ');
  };

  const handleEqual = () => {
    try {
      const result = eval(equation + display);
      setDisplay(String(result));
      setEquation('');
    } catch (error) {
      setDisplay('Error');
    }
    setShouldResetDisplay(true);
  };

  const handleClear = () => {
    setDisplay('0');
    setEquation('');
  };

  const Button = ({ children, onClick, className = '' }: { 
    children: React.ReactNode; 
    onClick: () => void; 
    className?: string;
  }) => (
    <button
      onClick={onClick}
      className={`p-4 text-xl rounded-lg transition-all duration-200 hover:bg-opacity-80 active:scale-95 ${className}`}
    >
      {children}
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center p-4">
      <div className="bg-gray-700 p-6 rounded-2xl shadow-2xl w-full max-w-xs">
        <div className="mb-4">
          <div className="text-gray-400 text-right h-6 text-sm mb-1">
            {equation}
          </div>
          <div className="bg-gray-800 p-4 rounded-lg">
            <div className="text-right text-white text-3xl font-light truncate">
              {display}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-2">
          <Button 
            onClick={handleClear} 
            className="bg-red-500 text-white col-span-2"
          >
            <Delete className="inline-block w-5 h-5 mr-1" />
            Clear
          </Button>
          <Button 
            onClick={() => handleOperator('/')} 
            className="bg-gray-600 text-white"
          >
            <Divide className="w-5 h-5" />
          </Button>
          <Button 
            onClick={() => handleOperator('*')} 
            className="bg-gray-600 text-white"
          >
            <X className="w-5 h-5" />
          </Button>
          
          {[7, 8, 9].map(num => (
            <Button 
              key={num} 
              onClick={() => handleNumber(String(num))}
              className="bg-gray-800 text-white"
            >
              {num}
            </Button>
          ))}
          <Button 
            onClick={() => handleOperator('-')} 
            className="bg-gray-600 text-white"
          >
            <Minus className="w-5 h-5" />
          </Button>
          
          {[4, 5, 6].map(num => (
            <Button 
              key={num} 
              onClick={() => handleNumber(String(num))}
              className="bg-gray-800 text-white"
            >
              {num}
            </Button>
          ))}
          <Button 
            onClick={() => handleOperator('+')} 
            className="bg-gray-600 text-white"
          >
            <Plus className="w-5 h-5" />
          </Button>
          
          {[1, 2, 3].map(num => (
            <Button 
              key={num} 
              onClick={() => handleNumber(String(num))}
              className="bg-gray-800 text-white"
            >
              {num}
            </Button>
          ))}
          <Button 
            onClick={handleEqual} 
            className="bg-blue-500 text-white row-span-2"
          >
            <Equal className="w-5 h-5" />
          </Button>
          
          <Button 
            onClick={() => handleNumber('0')} 
            className="bg-gray-800 text-white col-span-2"
          >
            0
          </Button>
          <Button 
            onClick={() => handleNumber('.')} 
            className="bg-gray-800 text-white"
          >
            .
          </Button>
        </div>
      </div>
    </div>
  );
}

export default App;