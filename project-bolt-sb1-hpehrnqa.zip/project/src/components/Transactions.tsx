import React from 'react';
import { ArrowUpRight, ArrowDownRight, Search } from 'lucide-react';

const transactions = [
  {
    id: 1,
    name: 'Grocery Store',
    type: 'expense',
    amount: 156.80,
    date: '2024-03-10',
    category: 'Shopping'
  },
  {
    id: 2,
    name: 'Salary Deposit',
    type: 'income',
    amount: 5200.00,
    date: '2024-03-01',
    category: 'Income'
  },
  {
    id: 3,
    name: 'Netflix Subscription',
    type: 'expense',
    amount: 15.99,
    date: '2024-03-05',
    category: 'Entertainment'
  },
  {
    id: 4,
    name: 'Freelance Payment',
    type: 'income',
    amount: 850.00,
    date: '2024-03-08',
    category: 'Income'
  },
];

const Transactions: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Recent Transactions</h1>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="Search transactions"
          />
        </div>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {transactions.map((transaction) => (
            <li key={transaction.id}>
              <div className="px-4 py-4 sm:px-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center ${
                      transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'
                    }`}>
                      {transaction.type === 'income' ? (
                        <ArrowUpRight className="h-6 w-6 text-green-600" />
                      ) : (
                        <ArrowDownRight className="h-6 w-6 text-red-600" />
                      )}
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">
                        {transaction.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {transaction.category}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <div className={`text-sm font-semibold ${
                      transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {transaction.type === 'income' ? '+' : '-'}${transaction.amount.toLocaleString()}
                    </div>
                    <div className="ml-4 text-sm text-gray-500">
                      {new Date(transaction.date).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Transactions;