import React, { useState } from 'react';
import { Building2, CreditCard, PieChart, Send, Settings, User } from 'lucide-react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Transactions from './components/Transactions';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const navigation = [
    { name: 'Dashboard', icon: <PieChart size={20} />, id: 'dashboard' },
    { name: 'Transactions', icon: <CreditCard size={20} />, id: 'transactions' },
    { name: 'Transfer', icon: <Send size={20} />, id: 'transfer' },
    { name: 'Profile', icon: <User size={20} />, id: 'profile' },
    { name: 'Settings', icon: <Settings size={20} />, id: 'settings' },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar 
        navigation={navigation} 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
      />
      <main className="flex-1 overflow-y-auto">
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            {activeTab === 'dashboard' && <Dashboard />}
            {activeTab === 'transactions' && <Transactions />}
            {/* Other components will be added for remaining tabs */}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;